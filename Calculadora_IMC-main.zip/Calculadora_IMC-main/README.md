# Calculadora_IMC
Olá, esse é um projeto feito usando o HTML, CSS e PHP. Sendo feito a ligação entre eles. 
